var data = {
  name : [
    {name: 'Name', value: 'Siddhanth Das'}
  ],
  bio: [
    {name: 'Name', value: 'Siddhanth Das'},
    {name: 'Email', value: 'siddhanthdas99@gmail.com'},
    {name: 'Phone', value: '+918777852961'},
    {name: 'Country', value: 'India'},
    {name: 'City', value: 'Kolkata'}
  ],
  github: [
    {name: 'GitHub', value: 'noobs-creation'}
  ],
  projects: [
    
  ],
  resume: 'Siddhanth_Das_cv.pdf',
  socials: [
    {name: 'LinkedIn', value: 'https://linkedin.com/in/siddhanthdas'},
    {name: 'GitHub', value: 'https://github.com/noobs-creation'},
    {name: 'Instagram', value: 'https://instagram.com/siddhanthdas'}
  ]
}